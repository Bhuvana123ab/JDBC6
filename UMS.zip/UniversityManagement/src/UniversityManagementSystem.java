import java.sql.*;

public class UniversityManagementSystem {
    // JDBC URL, username, and password of MySQL server
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/UniversityManagementSystem";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "Santhiya29*";

    public static void main(String[] args) {
        try {
            // Establishing a connection to the database
            Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);

            // Creating a statement object for executing SQL queries
            Statement statement = connection.createStatement();

            // Example of inserting data into the students table
            String insertQuery = "INSERT INTO students (name, age, major) VALUES ('John Doe', 20, 'Computer Science')";
            int rowsInserted = statement.executeUpdate(insertQuery);
            System.out.println(rowsInserted + " row(s) inserted.");

            // Example of updating data in the students table
            String updateQuery = "UPDATE students SET age = 21 WHERE name = 'John Doe'";
            int rowsUpdated = statement.executeUpdate(updateQuery);
            System.out.println(rowsUpdated + " row(s) updated.");

            // Example of deleting data from the students table
            String deleteQuery = "DELETE FROM students WHERE name = 'John Doe'";
            int rowsDeleted = statement.executeUpdate(deleteQuery);
            System.out.println(rowsDeleted + " row(s) deleted.");

            // Example of retrieving data from the students table
            String selectQuery = "SELECT * FROM students";
            ResultSet resultSet = statement.executeQuery(selectQuery);
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                int age = resultSet.getInt("age");
                String major = resultSet.getString("major");
                System.out.println("ID: " + id + ", Name: " + name + ", Age: " + age + ", Major: " + major);
            }

            // Closing the result set, statement, and connection
            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
